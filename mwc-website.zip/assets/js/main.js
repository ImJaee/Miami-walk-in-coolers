/* Miami Walk-In Cooler — site behavior */
(function () {
  'use strict';

  // Nav shrink on scroll
  var nav = document.querySelector('.nav');
  if (nav) {
    var onScroll = function () { nav.classList.toggle('scrolled', window.scrollY > 30); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // Mobile drawer
  var toggle = document.querySelector('.nav-toggle');
  var drawer = document.querySelector('.drawer');
  if (toggle && drawer) {
    var setDrawer = function (open) {
      drawer.classList.toggle('open', open);
      toggle.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    };
    toggle.addEventListener('click', function () { setDrawer(!drawer.classList.contains('open')); });
    drawer.addEventListener('click', function (e) {
      if (e.target.matches('.drawer-scrim') || e.target.closest('a')) setDrawer(false);
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setDrawer(false); });
  }

  // Reveal on scroll
  var revs = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revs.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revs.forEach(function (el) { io.observe(el); });
  } else {
    revs.forEach(function (el) { el.classList.add('in'); });
  }

  // Lightbox (gallery)
  var lb = document.querySelector('.lightbox');
  if (lb) {
    var lbBody = lb.querySelector('[data-lb-body]');
    document.querySelectorAll('.gallery figure').forEach(function (fig) {
      fig.addEventListener('click', function () {
        var img = fig.querySelector('img');
        var cap = fig.querySelector('figcaption');
        lbBody.innerHTML = img
          ? '<img src="' + img.getAttribute('src') + '" alt="' + (img.alt || '') + '">'
          : '<div class="ph lb-ph"><b>' + (cap ? cap.textContent : 'Project photo') + '</b><span>Add photo</span></div>';
        lb.classList.add('open');
        document.body.style.overflow = 'hidden';
      });
    });
    var closeLb = function () { lb.classList.remove('open'); document.body.style.overflow = ''; };
    lb.addEventListener('click', function (e) { if (e.target === lb || e.target.closest('.close')) closeLb(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeLb(); });
  }

  // Forms via Web3Forms
  document.querySelectorAll('form[data-web3form]').forEach(function (form) {
    var thanks = form.getAttribute('data-thanks') || 'Thanks! We will be in touch shortly.';
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      var btn = form.querySelector('[type="submit"]'); var orig = btn.innerHTML;
      btn.disabled = true; btn.innerHTML = 'Sending...';
      try {
        var res = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: new FormData(form) });
        var j = await res.json();
        if (!j.success) throw new Error(j.message || 'error');
        form.innerHTML = '<div class="form-done"><div class="tick">✓</div><h3>Thank You!</h3><p>' + thanks + '</p></div>';
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } catch (err) {
        btn.disabled = false; btn.innerHTML = orig;
        alert('Sorry, something went wrong. Please call (305) 555-5555 or email quotes@miamiwalkincooler.com.');
      }
    });
  });

  // Footer year
  var y = document.querySelector('[data-year]');
  if (y) y.textContent = new Date().getFullYear();
})();
